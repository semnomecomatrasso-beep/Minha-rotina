package com.example.meudia

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

// Tudo é guardado no próprio celular. O app nem pede permissão de internet.
object Store {
    private fun sp(c: Context) = c.getSharedPreferences("meudia", Context.MODE_PRIVATE)

    fun tema(c: Context): String = sp(c).getString("tema", "claro") ?: "claro"

    fun setTema(c: Context, t: String) {
        sp(c).edit().putString("tema", t).apply()
    }

    fun novoId(c: Context): Int {
        val n = sp(c).getInt("proximoId", 1)
        sp(c).edit().putInt("proximoId", n + 1).apply()
        return n
    }

    fun lista(c: Context, chave: String): MutableList<JSONObject> {
        val out = mutableListOf<JSONObject>()
        try {
            val a = JSONArray(sp(c).getString(chave, "[]") ?: "[]")
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (e: Exception) {
            // dados ilegíveis: começa vazio
        }
        return out
    }

    fun gravar(c: Context, chave: String, itens: List<JSONObject>) {
        val a = JSONArray()
        itens.forEach { a.put(it) }
        sp(c).edit().putString(chave, a.toString()).apply()
    }
}

object Agenda {

    // Próximo momento em que h:m vai acontecer (hoje ou amanhã)
    fun proximo(h: Int, m: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pendente(c: Context, id: Int): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
        i.putExtra("id", id)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun agendar(c: Context, l: JSONObject) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendente(c, l.optInt("id"))
        val t = proximo(l.optInt("h"), l.optInt("m"))
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        } else {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }

    fun cancelar(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendente(c, id))
    }

    fun reagendarTodos(c: Context) {
        for (l in Store.lista(c, "lembretes")) {
            if (l.optBoolean("ativo", true)) agendar(c, l)
        }
    }
}
