package com.example.meudia

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val itens = Store.lista(ctx, "lembretes")
        val l = itens.firstOrNull { it.optInt("id") == id } ?: return
        if (!l.optBoolean("ativo", true)) return

        notificar(ctx, id, l.optString("titulo"))

        if (l.optBoolean("repetir", true)) {
            Agenda.agendar(ctx, l)
        } else {
            l.put("ativo", false)
            Store.gravar(ctx, "lembretes", itens)
        }
    }

    private fun notificar(ctx: Context, id: Int, titulo: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("lembretes", "Lembretes", NotificationManager.IMPORTANCE_HIGH)
        )
        val abrir = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, "lembretes")
            .setContentTitle("⏰ Lembrete")
            .setContentText(titulo)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(abrir)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) Agenda.reagendarTodos(ctx)
    }
}
