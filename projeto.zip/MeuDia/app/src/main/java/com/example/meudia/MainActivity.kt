package com.example.meudia

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Paleta(
    val bg: Int, val card: Int, val texto: Int, val sub: Int,
    val primaria: Int, val trilho: Int, val perigo: Int, val ok: Int
)

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val CLARO = Paleta(
        Color.parseColor("#F5F6FA"), Color.WHITE, Color.parseColor("#1F2937"), Color.parseColor("#6B7280"),
        Color.parseColor("#6C7BFF"), Color.parseColor("#E5E7EF"), Color.parseColor("#F28B82"), Color.parseColor("#5CC9A7")
    )
    private val ESCURO = Paleta(
        Color.parseColor("#12141C"), Color.parseColor("#1E2230"), Color.parseColor("#F3F4F6"), Color.parseColor("#9CA3AF"),
        Color.parseColor("#8E9BFF"), Color.parseColor("#2D3244"), Color.parseColor("#F28B82"), Color.parseColor("#5CC9A7")
    )

    private val DIAS = listOf(
        2 to "Segunda-feira", 3 to "Terça-feira", 4 to "Quarta-feira", 5 to "Quinta-feira",
        6 to "Sexta-feira", 7 to "Sábado", 1 to "Domingo"
    )

    private lateinit var c: Paleta
    private var aba = 0
    private var relogio: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            atualizarRelogio()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val escuro = Store.tema(this) == "escuro"
        AppCompatDelegate.setDefaultNightMode(
            if (escuro) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
        super.onCreate(savedInstanceState)
        aba = savedInstanceState?.getInt("aba") ?: 0
        render()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("aba", aba)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun atualizarRelogio() {
        relogio?.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    // ---------- peças de interface ----------

    private fun forma(cor: Int, raio: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(raio).toFloat()
        g.setColor(cor)
        return g
    }

    private fun lp(w: Int, h: Int, mt: Int = 0, mb: Int = 0, ml: Int = 0, mr: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(ml, mt, mr, mb)
        return p
    }

    private fun texto(t: String, tam: Float, cor: Int, negrito: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = tam
        v.setTextColor(cor)
        if (negrito) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        return v
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = forma(c.card, 20)
        l.elevation = dp(2).toFloat()
        l.setPadding(dp(16), dp(14), dp(16), dp(14))
        l.layoutParams = lp(MATCH, WRAP, mb = dp(12))
        return l
    }

    private fun cardLinha(): LinearLayout {
        val l = card()
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    private fun botao(t: String, cor: Int, aoClicar: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.textSize = 17f
        b.setTextColor(Color.WHITE)
        b.setTypeface(b.typeface, android.graphics.Typeface.BOLD)
        b.gravity = Gravity.CENTER
        b.background = forma(cor, 16)
        b.isClickable = true
        b.setOnClickListener { aoClicar() }
        b.layoutParams = lp(MATCH, dp(56), mt = dp(4), mb = dp(12))
        return b
    }

    private fun iconeBtn(t: String, aoClicar: () -> Unit): TextView {
        val b = TextView(this)
        b.text = t
        b.textSize = 20f
        b.gravity = Gravity.CENTER
        b.isClickable = true
        b.setOnClickListener { aoClicar() }
        b.layoutParams = lp(dp(44), dp(44))
        return b
    }

    private fun cabecalho(col: LinearLayout, titulo: String, sub: String) {
        col.addView(texto(titulo, 28f, c.texto, true))
        val s = texto(sub, 15f, c.sub)
        s.setPadding(0, 0, 0, dp(16))
        col.addView(s)
    }

    private fun vazio(t: String): TextView {
        val v = texto(t, 15f, c.sub)
        v.gravity = Gravity.CENTER
        v.setPadding(dp(8), dp(24), dp(8), dp(24))
        return v
    }

    private fun barra(pct: Int): LinearLayout {
        val p = pct.coerceIn(0, 100)
        val trilho = LinearLayout(this)
        trilho.weightSum = 100f
        trilho.background = forma(c.trilho, 8)
        trilho.layoutParams = lp(MATCH, dp(14), mt = dp(8), mb = dp(8))
        val cheio = View(this)
        cheio.background = forma(if (p >= 100) c.ok else c.primaria, 8)
        trilho.addView(cheio, LinearLayout.LayoutParams(0, MATCH, p.toFloat()))
        trilho.addView(View(this), LinearLayout.LayoutParams(0, MATCH, (100 - p).toFloat()))
        return trilho
    }

    private fun botaoHora(rotulo: String): TextView {
        val b = texto(rotulo, 16f, c.texto, true)
        b.gravity = Gravity.CENTER
        b.background = forma(c.trilho, 12)
        b.setPadding(dp(12), dp(14), dp(12), dp(14))
        b.isClickable = true
        b.layoutParams = lp(MATCH, WRAP, mt = dp(8))
        return b
    }

    private fun fmt(h: Int, m: Int): String = String.format(Locale.US, "%02d:%02d", h, m)

    private fun escolherHora(atual: String, aoEscolher: (String) -> Unit) {
        val p = atual.split(":")
        TimePickerDialog(this, { _, h, m -> aoEscolher(fmt(h, m)) }, p[0].toInt(), p[1].toInt(), true).show()
    }

    private fun caixaDialogo(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(20), dp(12), dp(20), dp(4))
        return l
    }

    // ---------- estrutura ----------

    @Suppress("DEPRECATION")
    private fun render() {
        val escuro = Store.tema(this) == "escuro"
        c = if (escuro) ESCURO else CLARO
        window.statusBarColor = c.bg
        window.navigationBarColor = c.card
        var flags = 0
        if (!escuro) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags

        relogio = null
        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(c.bg)

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(28), dp(20), dp(24))
        when (aba) {
            0 -> abaInicio(col)
            1 -> abaTarefas(col)
            2 -> abaEstudos(col)
            3 -> abaLembretes(col)
            else -> abaMetas(col)
        }
        sv.addView(col)
        raiz.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        raiz.addView(barraAbas())
        setContentView(raiz)
        atualizarRelogio()
    }

    private fun barraAbas(): LinearLayout {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.HORIZONTAL
        b.setBackgroundColor(c.card)
        b.elevation = dp(8).toFloat()
        val abas = listOf("🏠" to "Início", "✅" to "Tarefas", "📚" to "Estudos", "⏰" to "Lembretes", "🎯" to "Metas")
        abas.forEachIndexed { i, par ->
            val emo = par.first
            val s = SpannableString(emo + "\n" + par.second)
            s.setSpan(RelativeSizeSpan(1.7f), 0, emo.length, 0)
            val t = TextView(this)
            t.text = s
            t.gravity = Gravity.CENTER
            t.textSize = 11f
            t.setTextColor(if (i == aba) c.primaria else c.sub)
            if (i == aba) t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
            t.setOnClickListener {
                aba = i
                render()
            }
            b.addView(t, LinearLayout.LayoutParams(0, dp(66), 1f))
        }
        return b
    }

    // ---------- início ----------

    private fun resumo(col: LinearLayout, titulo: String, linhas: String, destino: Int) {
        val cv = card()
        cv.addView(texto(titulo, 16f, c.texto, true))
        val t = texto(linhas, 15f, c.sub)
        t.setPadding(0, dp(4), 0, 0)
        cv.addView(t)
        cv.setOnClickListener {
            aba = destino
            render()
        }
        col.addView(cv)
    }

    private fun abaInicio(col: LinearLayout) {
        val hora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val saud = if (hora < 12) "Bom dia" else if (hora < 18) "Boa tarde" else "Boa noite"
        col.addView(texto(saud + " 👋", 18f, c.sub))
        val r = texto("", 52f, c.primaria, true)
        relogio = r
        col.addView(r)
        val data = SimpleDateFormat("EEEE, d 'de' MMMM 'de' yyyy", Locale("pt", "BR")).format(Date())
        val d = texto(data.replaceFirstChar { it.uppercase() }, 16f, c.texto)
        d.setPadding(0, 0, 0, dp(20))
        col.addView(d)

        val tarefas = Store.lista(this, "tarefas")
        val pend = tarefas.count { !it.optBoolean("done") }
        val feitas = tarefas.size - pend
        resumo(col, "✅ Tarefas", pend.toString() + " pendentes · " + feitas + " concluídas", 1)

        val hoje = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val slots = Store.lista(this, "estudos").filter { it.optInt("dia") == hoje }.sortedBy { it.optString("ini") }
        val txtEstudo = if (slots.isEmpty()) "Nenhum horário de estudo hoje"
        else slots.joinToString("\n") { it.optString("ini") + " – " + it.optString("fim") + "   " + it.optString("materia") }
        resumo(col, "📚 Estudos de hoje", txtEstudo, 2)

        val prox = Store.lista(this, "lembretes")
            .filter { it.optBoolean("ativo", true) }
            .minByOrNull { Agenda.proximo(it.optInt("h"), it.optInt("m")) }
        val txtLemb = if (prox == null) "Nenhum lembrete ativo"
        else fmt(prox.optInt("h"), prox.optInt("m")) + " · " + prox.optString("titulo")
        resumo(col, "⏰ Próximo lembrete", txtLemb, 3)

        val metas = Store.lista(this, "metas")
        val media = if (metas.isEmpty()) 0 else metas.sumOf { pctMeta(it) } / metas.size
        val cm = card()
        cm.addView(texto("🎯 Metas", 16f, c.texto, true))
        cm.addView(texto(if (metas.isEmpty()) "Nenhuma meta criada" else "Progresso geral: " + media + "%", 15f, c.sub))
        if (metas.isNotEmpty()) cm.addView(barra(media))
        cm.setOnClickListener {
            aba = 4
            render()
        }
        col.addView(cm)

        val escuro = Store.tema(this) == "escuro"
        col.addView(botao(if (escuro) "☀️  Modo claro" else "🌙  Modo escuro", c.primaria) { alternarTema() })
    }

    private fun alternarTema() {
        val escuro = Store.tema(this) == "escuro"
        Store.setTema(this, if (escuro) "claro" else "escuro")
        AppCompatDelegate.setDefaultNightMode(
            if (escuro) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        )
    }

    // ---------- tarefas ----------

    private fun abaTarefas(col: LinearLayout) {
        cabecalho(col, "Tarefas", "Organize o que precisa ser feito")
        col.addView(botao("＋  Nova tarefa", c.primaria) {
            dialogoTexto("Nova tarefa", "Ex: Fazer os exercícios") { t ->
                val lista = Store.lista(this, "tarefas")
                val o = JSONObject()
                o.put("id", Store.novoId(this))
                o.put("t", t)
                o.put("done", false)
                lista.add(o)
                Store.gravar(this, "tarefas", lista)
                render()
            }
        })
        val todas = Store.lista(this, "tarefas")
        if (todas.isEmpty()) col.addView(vazio("Nenhuma tarefa ainda.\nToque em “Nova tarefa” para começar."))
        for (t in todas.sortedBy { it.optBoolean("done") }) col.addView(linhaTarefa(t, todas))
        if (todas.any { it.optBoolean("done") }) {
            col.addView(botao("Limpar concluídas", c.sub) {
                Store.gravar(this, "tarefas", todas.filter { !it.optBoolean("done") })
                render()
            })
        }
    }

    private fun linhaTarefa(t: JSONObject, todas: MutableList<JSONObject>): LinearLayout {
        val feita = t.optBoolean("done")
        val cv = cardLinha()
        val marca = TextView(this)
        marca.text = if (feita) "✓" else ""
        marca.gravity = Gravity.CENTER
        marca.textSize = 20f
        marca.setTextColor(Color.WHITE)
        val bolinha = GradientDrawable()
        bolinha.shape = GradientDrawable.OVAL
        bolinha.setColor(if (feita) c.ok else Color.TRANSPARENT)
        bolinha.setStroke(dp(2), if (feita) c.ok else c.primaria)
        marca.background = bolinha
        marca.setOnClickListener {
            t.put("done", !feita)
            Store.gravar(this, "tarefas", todas)
            render()
        }
        cv.addView(marca, LinearLayout.LayoutParams(dp(44), dp(44)))
        val tx = texto(t.optString("t"), 17f, if (feita) c.sub else c.texto)
        tx.setPadding(dp(12), 0, dp(8), 0)
        if (feita) tx.paintFlags = tx.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        cv.addView(tx, LinearLayout.LayoutParams(0, WRAP, 1f))
        cv.addView(iconeBtn("🗑") {
            todas.remove(t)
            Store.gravar(this, "tarefas", todas)
            render()
        })
        return cv
    }

    private fun dialogoTexto(titulo: String, dica: String, aoSalvar: (String) -> Unit) {
        val et = EditText(this)
        et.hint = dica
        et.setSingleLine()
        val caixa = FrameLayout(this)
        caixa.setPadding(dp(20), dp(8), dp(20), 0)
        caixa.addView(et)
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setView(caixa)
            .setPositiveButton("Salvar") { _, _ ->
                val v = et.text.toString().trim()
                if (v.isNotEmpty()) aoSalvar(v)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- estudos ----------

    private fun abaEstudos(col: LinearLayout) {
        cabecalho(col, "Estudos", "Horários de estudo por matéria")
        col.addView(botao("＋  Novo horário", c.primaria) { dialogoEstudo() })
        val todos = Store.lista(this, "estudos")
        if (todos.isEmpty()) col.addView(vazio("Nenhum horário ainda.\nAdicione suas matérias e os dias de estudo."))
        val hoje = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        for (par in DIAS) {
            val dia = par.first
            val doDia = todos.filter { it.optInt("dia") == dia }.sortedBy { it.optString("ini") }
            if (doDia.isEmpty()) continue
            val rotulo = texto(par.second + (if (dia == hoje) "  • hoje" else ""), 15f, if (dia == hoje) c.primaria else c.sub, true)
            rotulo.setPadding(dp(4), dp(8), 0, dp(6))
            col.addView(rotulo)
            for (s in doDia) col.addView(linhaEstudo(s, todos))
        }
    }

    private fun linhaEstudo(s: JSONObject, todos: MutableList<JSONObject>): LinearLayout {
        val cv = cardLinha()
        val coluna = LinearLayout(this)
        coluna.orientation = LinearLayout.VERTICAL
        coluna.addView(texto(s.optString("materia"), 17f, c.texto, true))
        coluna.addView(texto(s.optString("ini") + " – " + s.optString("fim"), 14f, c.sub))
        cv.addView(coluna, LinearLayout.LayoutParams(0, WRAP, 1f))
        cv.addView(iconeBtn("🗑") {
            todos.remove(s)
            Store.gravar(this, "estudos", todos)
            render()
        })
        return cv
    }

    private fun dialogoEstudo() {
        val corpo = caixaDialogo()
        val materia = EditText(this)
        materia.hint = "Matéria (ex: Matemática)"
        materia.setSingleLine()
        corpo.addView(materia)

        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, DIAS.map { it.second })
        val hojeIdx = DIAS.indexOfFirst { it.first == Calendar.getInstance().get(Calendar.DAY_OF_WEEK) }
        spin.setSelection(if (hojeIdx >= 0) hojeIdx else 0)
        corpo.addView(spin, lp(MATCH, WRAP, mt = dp(8)))

        var ini = "08:00"
        var fim = "09:00"
        val tvIni = botaoHora("Início   " + ini)
        val tvFim = botaoHora("Fim   " + fim)
        tvIni.setOnClickListener {
            escolherHora(ini) { v ->
                ini = v
                tvIni.text = "Início   " + v
            }
        }
        tvFim.setOnClickListener {
            escolherHora(fim) { v ->
                fim = v
                tvFim.text = "Fim   " + v
            }
        }
        corpo.addView(tvIni)
        corpo.addView(tvFim)

        AlertDialog.Builder(this)
            .setTitle("Novo horário de estudo")
            .setView(corpo)
            .setPositiveButton("Salvar") { _, _ ->
                val m = materia.text.toString().trim()
                if (m.isEmpty()) {
                    toast("Digite o nome da matéria")
                } else if (fim <= ini) {
                    toast("O fim precisa ser depois do início")
                } else {
                    val lista = Store.lista(this, "estudos")
                    val o = JSONObject()
                    o.put("id", Store.novoId(this))
                    o.put("materia", m)
                    o.put("dia", DIAS[spin.selectedItemPosition].first)
                    o.put("ini", ini)
                    o.put("fim", fim)
                    lista.add(o)
                    Store.gravar(this, "estudos", lista)
                    render()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- lembretes ----------

    private fun pedirNotificacao() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun abaLembretes(col: LinearLayout) {
        cabecalho(col, "Lembretes", "Avisos no horário que você escolher")
        col.addView(botao("＋  Novo lembrete", c.primaria) {
            pedirNotificacao()
            dialogoLembrete()
        })
        val todos = Store.lista(this, "lembretes")
        if (todos.isEmpty()) col.addView(vazio("Nenhum lembrete ainda.\nEle aparece como notificação no horário."))
        for (l in todos.sortedBy { it.optInt("h") * 60 + it.optInt("m") }) col.addView(linhaLembrete(l, todos))
    }

    private fun linhaLembrete(l: JSONObject, todos: MutableList<JSONObject>): LinearLayout {
        val cv = cardLinha()
        val coluna = LinearLayout(this)
        coluna.orientation = LinearLayout.VERTICAL
        coluna.addView(texto(l.optString("titulo"), 17f, c.texto, true))
        val quando = fmt(l.optInt("h"), l.optInt("m")) + " · " + (if (l.optBoolean("repetir", true)) "Todo dia" else "Uma vez")
        coluna.addView(texto("⏰ " + quando, 14f, c.sub))
        cv.addView(coluna, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(this)
        sw.isChecked = l.optBoolean("ativo", true)
        sw.setOnCheckedChangeListener { _, ligado ->
            l.put("ativo", ligado)
            Store.gravar(this, "lembretes", todos)
            if (ligado) {
                pedirNotificacao()
                Agenda.agendar(this, l)
            } else {
                Agenda.cancelar(this, l.optInt("id"))
            }
        }
        cv.addView(sw)
        cv.addView(iconeBtn("🗑") {
            Agenda.cancelar(this, l.optInt("id"))
            todos.remove(l)
            Store.gravar(this, "lembretes", todos)
            render()
        })
        return cv
    }

    private fun dialogoLembrete() {
        val corpo = caixaDialogo()
        val titulo = EditText(this)
        titulo.hint = "Lembrar de… (ex: Tomar água)"
        titulo.setSingleLine()
        corpo.addView(titulo)

        val agora = Calendar.getInstance()
        var hora = fmt(agora.get(Calendar.HOUR_OF_DAY), agora.get(Calendar.MINUTE))
        val tvHora = botaoHora("⏰   " + hora)
        tvHora.setOnClickListener {
            escolherHora(hora) { v ->
                hora = v
                tvHora.text = "⏰   " + v
            }
        }
        corpo.addView(tvHora)

        val sw = Switch(this)
        sw.text = "Repetir todo dia"
        sw.isChecked = true
        sw.setPadding(0, dp(16), 0, dp(8))
        corpo.addView(sw)

        AlertDialog.Builder(this)
            .setTitle("Novo lembrete")
            .setView(corpo)
            .setPositiveButton("Salvar") { _, _ ->
                val t = titulo.text.toString().trim()
                if (t.isEmpty()) {
                    toast("Digite o que lembrar")
                } else {
                    val lista = Store.lista(this, "lembretes")
                    val o = JSONObject()
                    o.put("id", Store.novoId(this))
                    o.put("titulo", t)
                    o.put("h", hora.substring(0, 2).toInt())
                    o.put("m", hora.substring(3, 5).toInt())
                    o.put("repetir", sw.isChecked)
                    o.put("ativo", true)
                    lista.add(o)
                    Store.gravar(this, "lembretes", lista)
                    Agenda.agendar(this, o)
                    toast("Lembrete criado")
                    render()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- metas ----------

    private fun pctMeta(m: JSONObject): Int {
        val alvo = m.optInt("alvo")
        return if (alvo <= 0) 0 else (m.optInt("atual") * 100 / alvo).coerceIn(0, 100)
    }

    private fun abaMetas(col: LinearLayout) {
        cabecalho(col, "Metas", "Acompanhe seu progresso")
        col.addView(botao("＋  Nova meta", c.primaria) { dialogoMeta() })
        val metas = Store.lista(this, "metas")
        if (metas.isEmpty()) col.addView(vazio("Nenhuma meta ainda.\nEx: “Ler 10 livros” ou “Estudar 30 horas”."))
        for (m in metas) col.addView(cartaoMeta(m, metas))
    }

    private fun cartaoMeta(m: JSONObject, todas: MutableList<JSONObject>): LinearLayout {
        val cv = card()
        val topo = LinearLayout(this)
        topo.orientation = LinearLayout.HORIZONTAL
        topo.gravity = Gravity.CENTER_VERTICAL
        topo.addView(texto(m.optString("nome"), 18f, c.texto, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        topo.addView(iconeBtn("🗑") {
            todas.remove(m)
            Store.gravar(this, "metas", todas)
            render()
        })
        cv.addView(topo)

        val alvo = m.optInt("alvo")
        val atual = m.optInt("atual")
        val pct = pctMeta(m)
        val valor = texto(atual.toString() + " de " + alvo + "   (" + pct + "%)  ✏️", 15f, c.sub)
        valor.isClickable = true
        valor.setOnClickListener { dialogoValor(m, todas) }
        cv.addView(valor)
        cv.addView(barra(pct))
        if (pct >= 100) cv.addView(texto("🎉 Meta concluída!", 15f, c.ok, true))

        val botoes = LinearLayout(this)
        botoes.orientation = LinearLayout.HORIZONTAL
        val menos = botao("−", c.sub) {
            m.put("atual", (atual - 1).coerceAtLeast(0))
            Store.gravar(this, "metas", todas)
            render()
        }
        val mais = botao("＋", c.primaria) {
            m.put("atual", (atual + 1).coerceAtMost(alvo))
            Store.gravar(this, "metas", todas)
            render()
        }
        menos.layoutParams = lp(0, dp(52), mt = dp(8), mb = 0, mr = dp(6)).also { it.weight = 1f }
        mais.layoutParams = lp(0, dp(52), mt = dp(8), mb = 0, ml = dp(6)).also { it.weight = 1f }
        botoes.addView(menos)
        botoes.addView(mais)
        cv.addView(botoes)
        return cv
    }

    private fun dialogoMeta() {
        val corpo = caixaDialogo()
        val nome = EditText(this)
        nome.hint = "Nome da meta (ex: Ler livros)"
        nome.setSingleLine()
        val alvo = EditText(this)
        alvo.hint = "Quanto quer alcançar? (ex: 10)"
        alvo.inputType = InputType.TYPE_CLASS_NUMBER
        corpo.addView(nome)
        corpo.addView(alvo)
        AlertDialog.Builder(this)
            .setTitle("Nova meta")
            .setView(corpo)
            .setPositiveButton("Salvar") { _, _ ->
                val n = nome.text.toString().trim()
                val a = alvo.text.toString().toIntOrNull() ?: 0
                if (n.isEmpty() || a <= 0) {
                    toast("Preencha o nome e um número maior que zero")
                } else {
                    val lista = Store.lista(this, "metas")
                    val o = JSONObject()
                    o.put("id", Store.novoId(this))
                    o.put("nome", n)
                    o.put("alvo", a)
                    o.put("atual", 0)
                    lista.add(o)
                    Store.gravar(this, "metas", lista)
                    render()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun dialogoValor(m: JSONObject, todas: MutableList<JSONObject>) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.setText(m.optInt("atual").toString())
        val caixa = FrameLayout(this)
        caixa.setPadding(dp(20), dp(8), dp(20), 0)
        caixa.addView(et)
        AlertDialog.Builder(this)
            .setTitle("Quanto você já fez?")
            .setView(caixa)
            .setPositiveButton("Salvar") { _, _ ->
                val v = et.text.toString().toIntOrNull()
                if (v != null) {
                    m.put("atual", v.coerceIn(0, m.optInt("alvo")))
                    Store.gravar(this, "metas", todas)
                    render()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
